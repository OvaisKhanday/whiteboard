import { FC, useEffect, useState } from "react";
import { type Socket } from "socket.io-client";

interface ChatProps {
  socket: Socket;
}

const Chat: FC<ChatProps> = ({ socket }) => {
  const [messages, setMessages] = useState<string[]>([]);
  const [inputField, setInputField] = useState<string>("");
  useEffect(() => {
    socket.disconnected && socket.connect();
    socket.on("connect", () => {
      console.log("connected");
      socket.on("msg", (new_msg: string) => setMessages((prev) => [...prev, new_msg]));
    });
    socket.on("msg", (new_msg: string) => setMessages((prev) => [...prev, new_msg]));

    return () => {
      socket.off("msg");
      socket.disconnect();
    };
  }, []);

  function sendMsg() {
    socket.emit("msg", inputField);
    setInputField("");
  }

  return (
    <div>
      <div>
        {messages.map((ms) => (
          <p>{ms}</p>
        ))}
      </div>
      <input type='text' name='chat-message' value={inputField} onChange={(e) => setInputField(e.target.value)} />
      <button onClick={sendMsg}>send</button>
    </div>
  );
};

export default Chat;
