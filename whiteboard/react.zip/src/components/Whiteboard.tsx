/* eslint-disable @typescript-eslint/no-explicit-any */
import Konva from "konva";
import { FC, useEffect, useRef, useState } from "react";
import { Layer, Line, Stage } from "react-konva";
import { Socket } from "socket.io-client";

interface WhiteboardProps {
  socket: Socket;
}

const Whiteboard: FC<WhiteboardProps> = ({ socket }) => {
  const isDrawing = useRef(false);
  const [lines, setLines] = useState<number[][]>([]);

  useEffect(() => {
    socket.connect();
    socket.on("connect", () => console.log("socket connected"));
    socket.on("disconnect", () => console.log("socket disconnected"));
    return () => {
      socket.disconnect();
    };
  }, []);

  useEffect(() => {
    socket.on("new_line", (data) => {
      console.log(data);
      setLines((prev) => [...prev, data]);
    });
    socket.on("hello", (data) => {
      console.log(data);
    });

    // socket.on("ping", () => {
    //   console.log("ping");
    // });

    return () => {
      socket.off("new_line");
      console.log("off");
    };
  }, []);

  const handleMouseDown = (e: Konva.KonvaEventObject<globalThis.MouseEvent>) => {
    isDrawing.current = true;
    const pos = e.target.getStage()?.getPointerPosition();
    setLines([...lines, [pos!.x, pos!.y]]);
  };
  const handleMouseMove = (e: Konva.KonvaEventObject<globalThis.MouseEvent>) => {
    // no drawing - skipping
    if (!isDrawing.current) {
      return;
    }
    const stage = e.target.getStage();
    const point = stage?.getPointerPosition();
    let lastLine = lines[lines.length - 1];
    // add point
    lastLine = lastLine.concat([point!.x, point!.y]);
    // replace last
    lines.splice(lines.length - 1, 1, lastLine);
    setLines(lines.concat());
  };

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const handleMouseUp = (_e: Konva.KonvaEventObject<globalThis.MouseEvent>) => {
    isDrawing.current = false;
    socket.emit("new_line", lines[lines.length - 1]);
    console.log("emitted");
  };

  return (
    <div style={{ backgroundColor: "white" }}>
      <Stage
        width={window.innerWidth}
        height={window.innerHeight}
        onMouseDown={handleMouseDown}
        onMousemove={handleMouseMove}
        onMouseup={handleMouseUp}
      >
        <Layer>
          {lines.map((line, idx) => (
            <Line key={idx} points={line} stroke='red' />
          ))}
        </Layer>
      </Stage>
    </div>
  );
};

export default Whiteboard;
