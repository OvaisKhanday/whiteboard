import socketIO from "socket.io-client";
export const socket = socketIO("http://localhost:4000", {
  retries: 5,
  autoConnect: false,
});
