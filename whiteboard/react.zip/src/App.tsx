// import { useKeycloak } from "@react-keycloak/web";
import { useEffect, useState } from "react";
import "./App.css";
import { useKeycloak } from "@react-keycloak/web";
// import Whiteboard from "./components/Whiteboard";
import Chat from "./components/Chat";
import { socket } from "./socket";

function App() {
  const { keycloak } = useKeycloak();
  const [x, setX] = useState("");
  useEffect(() => {
    keycloak.loadUserInfo().then((userInfo) => {
      setX(JSON.stringify(userInfo, null, 2));
    });
  });

  return (
    <div>
      <pre style={{ textAlign: "left" }}>{x}</pre>
      {/* <Whiteboard socket={socket} /> */}
      <Chat socket={socket} />
    </div>
  );
}

export default App;
