// import { ReactKeycloakProvider } from "@react-keycloak/web";
import ReactDOM from "react-dom/client";
import App from "./App.js";
import "./index.css";
// import keycloak from "./keycloak.ts";
import keycloak from "./keycloak.ts";
import { ReactKeycloakProvider } from "@react-keycloak/web";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <ReactKeycloakProvider
    authClient={keycloak}
    onEvent={console.log}
    LoadingComponent={<h1>authenticating...</h1>}
    initOptions={{ onLoad: "login-required" }}
  >
    {/* <React.StrictMode> */}
    <App />
    {/* </React.StrictMode> */}
  </ReactKeycloakProvider>
);
